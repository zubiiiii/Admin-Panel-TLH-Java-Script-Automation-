const { expect } = require("@playwright/test");

class ActiveappCR {
    constructor(page) {
        this.page = page;
        this.usernameField = '#exampleInputEmail1';  
        this.passwordField = '#exampleInputPassword1';  
        this.loginButton = 'xpath=//*[@id="root"]/div/div/div/div[2]/div/div[2]/form/div/div[3]/button';    
        this.OTPinput1="#otp-input-0"
        this.OTPinput2="#otp-input-1"
        this.OTPinput3="#otp-input-2"
        this.OTPinput4="#otp-input-3"
        this.OTPinput5="#otp-input-4"
        this.OTPinput6="#otp-input-5"
        this.OTPLoginButton='//*[@id="root"]/div/div/div/div[2]/div/div[2]/form/div/div[2]/button'
        this.LoanApplicationclick='//*[@id="root"]/div/div[1]/div/div[2]/div/div[3]/h2/button'
        this.ActiveApplicationsclick='//*[@id="root"]/div/div[1]/div/div[2]/div/div[3]/div/div/div/div[1]'
        this.ActiveApplicationsclickView='//*[@id="root"]/div/div[2]/div[4]/div[2]/div/table/tbody/tr[1]/td[11]/div'
        this.ViewContract='//*[@id="0193ab93-d89b-735e-8eb8-00859fa90409"]/div/div[2]/form/div[1]/div/div/div[17]/div/a'
        this.CancelRefundbutton='//*[@id="0193ab93-d89b-735e-8eb8-00859fa90409"]/div/div[2]/form/div[2]/div/div[2]/div'
        this.CancelRefundYesbutton='body > div.fade.banForm.confirm.modal.show > div > div > div.modal-body > div > button.btn-white.me-3.btn.btn-primary'
    }

    async open(url) {
        await this.page.goto(url);
    }

    async enterUsername(username) {
        await this.page.fill(this.usernameField, username);
    }
    async enterotp1(Otp) {
        await this.page.fill(this.OTPinput1, Otp);
    }

    async enterotp2(Otp) {
        await this.page.fill(this.OTPinput2, Otp);
    }
    async enterotp3(Otp) {
        await this.page.fill(this.OTPinput3, Otp);
    }

    async enterotp4(Otp) {
        await this.page.fill(this.OTPinput4, Otp);
    } 

    async enterotp5(Otp) {
        await this.page.fill(this.OTPinput5, Otp);
    }

    async enterotp6(Otp) {
        await this.page.fill(this.OTPinput6, Otp);
    }

    async enterPassword(password) {
        await this.page.fill(this.passwordField, password);
    }

    async clickLogin() {
        await this.page.click(this.loginButton);
    }

    async clickOTP() {
        await this.page.click(this.OTPLoginButton);
    }

    async loanApplicationclick() {
        await this.page.click(this.LoanApplicationclick);
    }

    async activeApplicationsclick() {
        await this.page.click(this.ActiveApplicationsclick);
    }
    
    async activeApplicationsclickView() {
        await this.page.click(this.ActiveApplicationsclickView);
    }

    async viewContract() {
        await this.page.click(this.ViewContract);
    }

    async cancelRefundbutton() {
        await this.page.click(this.CancelRefundbutton);
    }

    async cancelRefundYesbutton() {
        await this.page.click(this.CancelRefundYesbutton);
    }


    async login(username, password) {
        await this.enterUsername(username);
        await this.enterPassword(password);
        await this.clickLogin();
        // await expect(this.page).toHaveURL('http://admin-dev.thelendinghub.sa/otp');
        await this.enterotp1("0")
        await this.enterotp2("0")
        await this.enterotp3("0")
        await this.enterotp4("0")
        await this.enterotp5("0")
        await this.enterotp6("0")
        await this.clickOTP();
        await this.loanApplicationclick();
        await this.activeApplicationsclick();
        await this.page.waitForTimeout(3000)
        await this.activeApplicationsclickView();
        await this.page.waitForTimeout(5000)
        await this.viewContract();
        await this.page.waitForTimeout(5000)
        await this.cancelRefundbutton();
        await this.page.waitForTimeout(3000)
        await this.cancelRefundYesbutton();
        await this.page.waitForTimeout(5000)

    }

    
}

module.exports = ActiveappCR;
