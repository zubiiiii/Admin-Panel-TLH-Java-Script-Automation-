
const { test, expect } = require('@playwright/test');
const EditProfile = require('../Pages/EditProfile');

test('Login Page Test - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const editProfile = new EditProfile(page);
    
    
    await editProfile.open('http://admin-uat.thelendinghub.sa/');
    
    
    await editProfile.login('thelendinghub.theproject@gmail.com', 'Admin123!@##');
    

    


});