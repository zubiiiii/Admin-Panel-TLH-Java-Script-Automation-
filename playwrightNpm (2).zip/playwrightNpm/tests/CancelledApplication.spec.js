const { test, expect } = require('@playwright/test');
const CancelledApplication = require('../Pages/CancelledApplication');

test('Cancelled Application - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const cancelledApplication = new CancelledApplication(page);
    
    
    await cancelledApplication.open('http://admin-uat.thelendinghub.sa/');
    
    
    await cancelledApplication.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

});