const { test, expect } = require('@playwright/test');
const PlatformWallets = require('../Pages/PlatformWallets');

test('Platform Wallets Test - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const platformWallets = new PlatformWallets(page);
    
    
    await platformWallets.open('http://admin-uat.thelendinghub.sa/');
    
    
    await platformWallets.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});