
const { test, expect } = require('@playwright/test');
const LoginPage = require('../Pages/LoginPage');

test('Login Page Test - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const loginPage = new LoginPage(page);
    
    
    await loginPage.open('http://admin-uat.thelendinghub.sa/');
    
    
    await loginPage.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});