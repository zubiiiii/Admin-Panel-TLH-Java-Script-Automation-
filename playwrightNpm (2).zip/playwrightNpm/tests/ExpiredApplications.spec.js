const { test, expect } = require('@playwright/test');
const ExpiredApplication = require('../Pages/ExpiredApplications');

test('ExpiredApplication Test - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const expiredApplication = new ExpiredApplication(page);
    
    
    await expiredApplication.open('http://admin-uat.thelendinghub.sa/');
    
    
    await expiredApplication.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});