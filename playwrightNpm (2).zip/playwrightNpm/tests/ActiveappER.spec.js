
const { test, expect } = require('@playwright/test');
const ActiveappER = require('../Pages/ActiveappER');

test('ActiveappER - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const activeappER = new ActiveappER(page);
    
    
    await activeappER.open('http://admin-uat.thelendinghub.sa/');
    
    
    await activeappER.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});