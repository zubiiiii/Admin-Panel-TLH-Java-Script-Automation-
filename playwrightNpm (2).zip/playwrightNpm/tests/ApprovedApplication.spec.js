const { test, expect } = require('@playwright/test');
const ApprovedApplication = require('../Pages/ApprovedApplication');

test('Approved Applications - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const approvedApplication = new ApprovedApplication(page);
    
    
    await approvedApplication.open('http://admin-uat.thelendinghub.sa/');
    
    
    await approvedApplication.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});