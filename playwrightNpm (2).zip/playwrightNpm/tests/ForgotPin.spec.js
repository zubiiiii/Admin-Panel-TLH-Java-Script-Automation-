
const { test, expect } = require('@playwright/test');
const ForgotPin = require('../Pages/ForgotPin');

test('Forgot Pin Test - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const forgotPin = new ForgotPin(page);
    
    
    await forgotPin.open('http://admin-uat.thelendinghub.sa/');
    
    
    await forgotPin.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});