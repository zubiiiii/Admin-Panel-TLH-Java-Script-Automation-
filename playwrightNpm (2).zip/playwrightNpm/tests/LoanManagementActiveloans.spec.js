const { test, expect } = require('@playwright/test');
const LoanManagementActiveloans = require('../Pages/LoanManagementActiveloans');

test('Loan Management Active loans Test - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const loanManagementActiveloans = new LoanManagementActiveloans(page);
    
    
    await loanManagementActiveloans.open('http://admin-uat.thelendinghub.sa/');
    
    
    await loanManagementActiveloans.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

});