const { test, expect } = require('@playwright/test');
const AllWallets = require('../Pages/AllWallets');

test('All Wallets Test - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const allWallets = new AllWallets(page);
    
    
    await allWallets.open('http://admin-uat.thelendinghub.sa/');
    
    
    await allWallets.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});