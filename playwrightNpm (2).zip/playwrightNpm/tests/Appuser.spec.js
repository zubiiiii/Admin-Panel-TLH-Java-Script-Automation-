const { test, expect } = require('@playwright/test');
const Appuser = require('../Pages/Appuser');

test('App usermanagment Test - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const appuser = new Appuser(page);
    
    
    await appuser.open('http://admin-uat.thelendinghub.sa/');
    
    
    await appuser.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

});