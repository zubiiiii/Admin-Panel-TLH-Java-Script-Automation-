const { test, expect } = require('@playwright/test');
const RejectedApplications = require('../Pages/RejectedApplications');

test('Rejected Applications - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const rejectedApplications = new RejectedApplications(page);
    
    
    await rejectedApplications.open('http://admin-uat.thelendinghub.sa/');
    
    
    await rejectedApplications.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});