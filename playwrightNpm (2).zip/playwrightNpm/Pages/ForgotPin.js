const { expect } = require("@playwright/test");

class ForgotPin {
    constructor(page) {
        this.page = page; 
        this.clickforgotyourpassword = '//*[@id="root"]/div/div/div/div[2]/div/div[2]/form/div/a';    
        this.Enterforgotemail='#newPassword'
        this.Submitbutton='//*[@id="root"]/div/div/div/div[2]/div/div[2]/form/div/div[2]'

    }

    async open(url) {
        await this.page.goto(url);
    }


    async Clickforgotyourpassword() {
        await this.page.click(this.clickforgotyourpassword);
    }

    async enterforgotemail(forgot) {
        await this.page.fill(this.Enterforgotemail, forgot);
    }

    async submitbutton() {
        await this.page.click(this.Submitbutton);
    }

    async login(username, password) {

        await this.Clickforgotyourpassword();
        await this.page.waitForTimeout(3000) 
        await this.enterforgotemail('testing@mailinator.com');
        await this.submitbutton();
        await this.page.waitForTimeout(3000) 

    }

    
}

module.exports = ForgotPin;
