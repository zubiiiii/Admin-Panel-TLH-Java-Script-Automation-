const { expect } = require("@playwright/test");

class Appuser {
    constructor(page) {
        this.page = page;
        this.usernameField = '#exampleInputEmail1';  
        this.passwordField = '#exampleInputPassword1';  
        this.loginButton = 'xpath=//*[@id="root"]/div/div/div/div[2]/div/div[2]/form/div/div[3]/button';    
        this.OTPinput1="#otp-input-0"
        this.OTPinput2="#otp-input-1"
        this.OTPinput3="#otp-input-2"
        this.OTPinput4="#otp-input-3"
        this.OTPinput5="#otp-input-4"
        this.OTPinput6="#otp-input-5"
        this.OTPLoginButton='//*[@id="root"]/div/div/div/div[2]/div/div[2]/form/div/div[2]/button'
        this.AppUserManagment='//*[@id="root"]/div/div[1]/div/div[2]/div/div[2]/h2/button/div[2]'
        this.PendingAccountApprovalsButton = '//*[@id="root"]/div/div[1]/div/div[2]/div/div[2]/div/div/div/div[3]/a'
        this.PendingAccountApprovalsButtonView='//*[@id="root"]/div/div[2]/div[4]/div[2]/div/table/tbody/tr[1]/td[6]/div';
        this.applybuttonapprove='//*[@id="root"]/div/div[2]/div[3]/div[2]/div[6]/div/div/form/button';
        this.Approvebutton='body > div.fade.userPepModal.modal.show > div > div > div.modal-footer > button.btn.btn-secondary'
    }

    async open(url) {
        await this.page.goto(url);
    }

    async enterUsername(username) {
        await this.page.fill(this.usernameField, username);
    }
    async enterotp1(Otp) {
        await this.page.fill(this.OTPinput1, Otp);
    }

    async enterotp2(Otp) {
        await this.page.fill(this.OTPinput2, Otp);
    }
    async enterotp3(Otp) {
        await this.page.fill(this.OTPinput3, Otp);
    }

    async enterotp4(Otp) {
        await this.page.fill(this.OTPinput4, Otp);
    } 

    async enterotp5(Otp) {
        await this.page.fill(this.OTPinput5, Otp);
    }

    async enterotp6(Otp) {
        await this.page.fill(this.OTPinput6, Otp);
    }

    async enterPassword(password) {
        await this.page.fill(this.passwordField, password);
    }

    async clickLogin() {
        await this.page.click(this.loginButton);
    }

     async PendingAccountApprovalsButtonClick() {
        await this.page.click(this.PendingAccountApprovalsButton);
    }
    async clickOTP() {
        await this.page.click(this.OTPLoginButton);
    }

    async AppUserManagmentclick() {
        await this.page.click(this.AppUserManagment);
    }

    async approvebutton(){
        await this.page.click(this.Approvebutton);
    }

    async Applybuttonapprove() {
        await this.page.click(this.applybuttonapprove);
    }

    async AppUserManagmentClickView() {
        await this.page.click(this.PendingAccountApprovalsButtonView);
    }

    async PendingAccountApprovalsButtonClick(){
        await this.page.click(this.PendingAccountApprovalsButton);
       

    }



    async login(username, password) {
        await this.enterUsername(username);
        await this.enterPassword(password);
        await this.clickLogin();
        // await expect(this.page).toHaveURL('http://admin-dev.thelendinghub.sa/otp');
        await this.enterotp1("0")
        await this.enterotp2("0")
        await this.enterotp3("0")
        await this.enterotp4("0")
        await this.enterotp5("0")
        await this.enterotp6("0")
        await this.clickOTP();
        await this.AppUserManagmentclick();
        await this.PendingAccountApprovalsButtonClick();
        await this.AppUserManagmentClickView();
        await this.page.waitForTimeout(7000);
        await this.page.waitForTimeout(7000);
        await this.page.selectOption('#formGridState', 'Approve Profile');
        await this.Applybuttonapprove();
        await this.page.waitForTimeout(7000);
        await this.approvebutton();
        await this.page.waitForTimeout(17000);
        
    }

    
}

module.exports = Appuser;
