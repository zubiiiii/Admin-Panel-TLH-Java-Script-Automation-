
const { test, expect } = require('@playwright/test');
const PendingApplications = require('../Pages/PendingApplications');

test('Pending applications - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const pendingApplications = new PendingApplications(page);
    
    
    await pendingApplications.open('http://admin-uat.thelendinghub.sa/');
    
    
    await pendingApplications.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});