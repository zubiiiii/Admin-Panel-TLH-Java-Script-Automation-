const { test, expect } = require('@playwright/test');
const ResendOTP = require('../Pages/ResendOTP');

test('Resend OTP - Successful', async ({ page }) => {

    test.setTimeout(0);
    const resendOTP = new ResendOTP(page);
    
    
    await resendOTP.open('http://admin-uat.thelendinghub.sa/');
    
    
    await resendOTP.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});