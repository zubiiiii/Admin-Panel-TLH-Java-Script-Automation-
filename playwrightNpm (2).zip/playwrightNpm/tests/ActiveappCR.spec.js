const { test, expect } = require('@playwright/test');
const ActiveappCR = require('../Pages/ActiveappCR');

test('ActiveappCR Test - Successful Login', async ({ page }) => {

    test.setTimeout(0);
    const activeappCR = new ActiveappCR(page);
    
    
    await activeappCR.open('http://admin-uat.thelendinghub.sa/');
    
    
    await activeappCR.login('thelendinghub.theproject@gmail.com', 'Admin123!@#');
    

    


});