const { expect } = require("@playwright/test");

class ResendOTP {
    constructor(page) {
        this.page = page;
        this.usernameField = '#exampleInputEmail1';  
        this.passwordField = '#exampleInputPassword1';  
        this.loginButton = 'xpath=//*[@id="root"]/div/div/div/div[2]/div/div[2]/form/div/div[3]/button';    
        this.OTPinput1="#otp-input-0"
        this.OTPinput2="#otp-input-1"
        this.OTPinput3="#otp-input-2"
        this.OTPinput4="#otp-input-3"
        this.OTPinput5="#otp-input-4"
        this.OTPinput6="#otp-input-5"
        this.OTPLoginButton='//*[@id="root"]/div/div/div/div[2]/div/div[2]/form/div/div[2]/button'
        this.ResendOTP='//*[@id="root"]/div/div/div/div[2]/div/div[2]/form/div/div[1]/div/div[2]/button'
    }

    async open(url) {
        await this.page.goto(url);
    }

    async enterUsername(username) {
        await this.page.fill(this.usernameField, username);
    }
    async enterotp1(Otp) {
        await this.page.fill(this.OTPinput1, Otp);
    }

    async enterotp2(Otp) {
        await this.page.fill(this.OTPinput2, Otp);
    }
    async enterotp3(Otp) {
        await this.page.fill(this.OTPinput3, Otp);
    }

    async enterotp4(Otp) {
        await this.page.fill(this.OTPinput4, Otp);
    } 

    async enterotp5(Otp) {
        await this.page.fill(this.OTPinput5, Otp);
    }

    async enterotp6(Otp) {
        await this.page.fill(this.OTPinput6, Otp);
    }

    async enterPassword(password) {
        await this.page.fill(this.passwordField, password);
    }

    async clickLogin() {
        await this.page.click(this.loginButton);
    }

    async clickOTP() {
        await this.page.click(this.OTPLoginButton);
    }

    async resendOTP() {
        await this.page.click(this.ResendOTP);
    }


    async login(username, password) {
        await this.enterUsername(username);
        await this.enterPassword(password);
        await this.clickLogin();
        await this.page.waitForTimeout(63000);
        // await expect(this.page).toHaveURL('http://admin-dev.thelendinghub.sa/otp');
        await this.enterotp1("0")
        await this.enterotp2("0")
        await this.enterotp3("0")
        await this.enterotp4("0")
        await this.enterotp5("0")
        await this.enterotp6("0")
        await this.resendOTP();
        await this.clickOTP();
        await this.page.waitForTimeout(5000);

    }

    
}

module.exports = ResendOTP;
